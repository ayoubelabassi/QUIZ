var mysql = require('mysql')
var connection = mysql.createConnection({
  host     : '185.224.138.113',
  user     : 'u153751443_quiz',
  password : 'u153751443_pass',
  database : 'u153751443_quiz'
});

module.exports=connection;